// Section 19
// Challenge 3
// Word counter
#include <iostream>

using namespace std;

int main() {
    
    
    cout << endl;
    return 0;
}

